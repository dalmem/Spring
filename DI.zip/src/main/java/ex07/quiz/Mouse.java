package ex07.quiz;

public class Mouse {
	
	public void info() {
		System.out.println("미키마우스");
	}
}
