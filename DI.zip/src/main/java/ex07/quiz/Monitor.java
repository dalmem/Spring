package ex07.quiz;

public class Monitor {
	
	public void info() {
		System.out.println("apple");
	}
}
