package ex04.quiz;

public interface IBattery {
	
	public void energy();
}
