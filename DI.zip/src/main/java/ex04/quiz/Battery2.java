package ex04.quiz;

public class Battery2 implements IBattery{
	
	public void energy() {
		System.out.println("노란건전지");
	}
}
