package ex04.quiz;

public class Airplane {
	private IBattery battery;
	
	
	
	//getter
	public IBattery getBattery() {
		return battery;
	}
	
	public void setBattery(IBattery battery) {
		this.battery = battery;
	}
}
