package ex04.quiz;

public class Battery1 implements IBattery{
	
	public void energy() {
		System.out.println("에너자이저");
	}
}
