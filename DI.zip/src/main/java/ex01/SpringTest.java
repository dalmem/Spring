package ex01;

public class SpringTest {
	
	public void test() {
		System.out.println("메이븐 프로젝트!?");
	}
}
