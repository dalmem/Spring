package ex02.construct;

public class Chef {
	
	public void cooking() {
		System.out.println("백종원 입니다");
	}
}
