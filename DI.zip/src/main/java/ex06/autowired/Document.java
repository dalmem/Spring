package ex06.autowired;

public class Document {
	public String data = "의존객체 자동주입 명령, Autowired는 타입으로 지정, Resource는 이름으로 지정";
}
