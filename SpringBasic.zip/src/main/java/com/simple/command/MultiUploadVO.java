package com.simple.command;

import java.util.List;

import lombok.Data;

@Data
public class MultiUploadVO {
	
	private List<UploadVO> getList;
}
